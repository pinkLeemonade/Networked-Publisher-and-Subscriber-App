import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

public class PubSubClient {
    private Socket client;
    private DataInputStream input;
    private DataOutputStream output;

    public PubSubClient() {
        runClient();
    }

    public void runClient() {
        try {
            System.out.println("Client started");

            // Connect to the server on port 500
            client = new Socket(InetAddress.getLocalHost(), 500);
            System.out.println("Connected to server at: " + client.getInetAddress().getHostName());

            // Get input and output streams
            input = new DataInputStream(client.getInputStream());
            output = new DataOutputStream(client.getOutputStream());


            // Read welcome message
            System.out.println("Server: " + input.readUTF());

            // Create a thread to listen for server messages
            new Thread(new ServerListener()).start();

            // Send messages to server
            Scanner scanner = new Scanner(System.in);
            String userInput;
            while ((userInput = scanner.nextLine()) != null) {
                output.writeUTF(userInput);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class ServerListener implements Runnable {
        @Override
        public void run() {
            try {
                // Listening to messages from the server
                while (true) {
                    String message = input.readUTF(); // Reading server messages
                    System.out.println( message+"\n");  // Log the server's message
                }
            } catch (EOFException eof) {
                // Handle the end of the stream
                System.out.println("Connection closed by server.");
            } catch (IOException e) {
                e.printStackTrace();  // Handle any other I/O exceptions
            } finally {
                try {
                    input.close();  // Clean up the resources
                    client.close();  // Close the socket
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    public static void main(String[] args) {
        new PubSubClient();
    }
}
