import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class ClientHandler implements Runnable, Subscriber {
    private Socket connection;
    private int clientID;
    private PubSubBrokerServer server;
    private DataInputStream dis;
    private DataOutputStream dos;
    static List<Object> topics = new ArrayList<>();

    public ClientHandler(Socket connection, int clientID, PubSubBrokerServer server) {
        this.connection = connection;
        this.clientID = clientID;
        this.server = server;
        topics.add("Data Analytics");
        topics.add("Cloud Computing");
        topics.add("Android Development");

    }

    @Override
    public void run() {
        try {
            dis = new DataInputStream(connection.getInputStream());
            dos = new DataOutputStream(connection.getOutputStream());

            // Send client its ID
            dos.writeUTF("Client ID : " + clientID);
            dos.writeUTF("Topics available for subscriptions:  "+ topics);
            dos.writeUTF("\n1.Subscribe to a topic.\n2.Unsubscribe on a topic.\n3.Publish on a topic\n" +
                    "4.View Topic Subscriptions.");
            String input;
            while ((input = dis.readUTF()) != null) {
                int command = Integer.parseInt(input);

                switch (command) {
                    case 1: // Subscribe
                        dos.writeUTF("Enter any topic of your choice  you want to subscribe to:");
                        String topicToSubscribe = dis.readUTF();
                        server.handleSubscribe(clientID, topicToSubscribe);
                        dos.writeUTF("Subscribed to " + topicToSubscribe);
                        break;

                    case 2: // Unsubscribe
                        dos.writeUTF("Enter the topic you want to unsubscribe from:");
                        String topicToUnsubscribe = dis.readUTF();
                        server.handleUnsubscribe(clientID, topicToUnsubscribe);
                        dos.writeUTF("Unsubscribed from " + topicToUnsubscribe);
                        break;

                    case 3: // Publish
                        dos.writeUTF("Enter the topic you want to publish on:");
                        String topicToPublish = dis.readUTF();
                        dos.writeUTF("Enter the message: ");
                        String message = dis.readUTF();
                        server.handlePublish(clientID, topicToPublish, message);
                        dos.writeUTF("Published message to " + topicToPublish);
                        break;


                    case 4:
                        dos.writeUTF("List of Topics  subscribed to : "+ server.getTopics());
                        break;
                    default:
                        dos.writeUTF("Unknown command. Please choose 1, 2, 3, etc");
                        break;
                }

                // Prompt user again after each action
                dos.writeUTF("\n1. Subscribe to a topic.\n2. Unsubscribe from a topic.\n3. Publish on a topic\n" +
                        "4. View my  subscriptions.\n. ");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                connection.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onPublished(Object publisher, String topic, String message) {
        try {
            dos.writeUTF("Message received on topic " + topic + " from publisher " + publisher+"\nMessage published: "+message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
