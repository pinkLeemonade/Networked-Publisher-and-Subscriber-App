import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class PubSubBrokerServer {
    private Map<Integer, ClientHandler> clients = new ConcurrentHashMap<>();
    private Map<String, Set<Subscriber>> subscribers = new ConcurrentHashMap<>();
    private PubSubBroker broker; // Implementing thread-safe broker
    private int clientIDCounter = 0;
    private ServerSocket serverSocket;
    private final Lock lock = new ReentrantLock();

    public PubSubBrokerServer() {
        broker = PubSubBroker.getInstance();
    }

    public static void main(String[] args) {
        new PubSubBrokerServer().startServer(500);  // Port 500
    }

    public void startServer(int port) {
        try {
            serverSocket = new ServerSocket(port);
            System.out.println("SERVER: Server started at "
                    + InetAddress.getLocalHost().getHostAddress() + ":" + port);

            while (true) {
                // Accept new client connection
                Socket connection = serverSocket.accept();
                int clientID;

                // Use lock to safely update client ID
                lock.lock();
                try {
                    clientID = ++clientIDCounter;
                } finally {
                    lock.unlock();
                }

                System.out.println("SERVER: Client " + clientID + " connected from "
                        + connection.getInetAddress().getHostName());

                // Create a new handler for the client
                ClientHandler clientHandler = new ClientHandler(connection, clientID, this);
                clients.put(clientID, clientHandler);

                // Start client handler in a new thread
                new Thread(clientHandler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void handleSubscribe(int clientID, String topic) {
        lock.lock();
        try {
            Set<Subscriber> subscriberSet = subscribers.computeIfAbsent(topic, key -> ConcurrentHashMap.newKeySet());
            subscriberSet.add(clients.get(clientID));

            System.out.println("SERVER: Client " + clientID + " subscribed to topic: " + topic);
        } finally {
            lock.unlock();
        }
    }

    public void handlePublish(int clientID, String topic, String message) {
        Set<Subscriber> subscriberSet = subscribers.get(topic);

        // If no subscribers for the topic, done!
        if (subscriberSet == null) {
            return;
        }

        // Notify all subscribers of the publishing of the message.
        subscriberSet.forEach(subscriber -> subscriber.onPublished(clientID, topic, message));
        System.out.println("SERVER: Client " + clientID + " published to topic: " + topic);
    }

    public void handleUnsubscribe(int clientID, String topic) {
        lock.lock();
        try {
            Set<Subscriber> subscriberSet = subscribers.get(topic);

            // If no-one listening, stop.
            if (subscriberSet == null) {
                return;
            }

            // Remove from set.
            subscriberSet.remove(clients.get(clientID));

            // Empty set? If so, remove the set.
            if (subscriberSet.isEmpty()) {
                subscribers.remove(topic);
            }

            System.out.println("SERVER: Client " + clientID + " unsubscribed from topic: " + topic);
        } finally {
            lock.unlock();
        }
    }

    public Set<Object> getTopics() {
        return Collections.unmodifiableSet(subscribers.keySet());
    }
}
