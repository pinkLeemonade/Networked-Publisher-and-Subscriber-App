@FunctionalInterface
public interface Subscriber {
    public int Id = 0;
    void onPublished(Object publisher, String topic, String message);
}