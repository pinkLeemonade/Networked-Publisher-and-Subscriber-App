import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class PubSubBroker {
    // Collection of subscribers. Maps topic onto set of subscribers.
    private Map<String, Set<Subscriber>> subscribers;
    private final Lock lock = new ReentrantLock();
    // Singleton instance of the broker.
    private static volatile PubSubBroker instance = null;

    // Made private so only can be called by self.
    private PubSubBroker() {
        subscribers = new ConcurrentHashMap<>();//to ensure thread safety
    }

    // Provides access to a single instance of a broker.
    public static PubSubBroker getInstance() {
        if (instance == null) {
            synchronized (PubSubBroker.class) {
                if (instance == null) {
                    instance = new PubSubBroker();
                }
            }
        }
        return instance;
    }

    public void subscribe(String topic, Subscriber subscriber) {
        lock.lock();
        try {
            // Get set of subscribers listening to topic. If none, create a new set.
            subscribers.computeIfAbsent(topic, key -> new HashSet<>()).add(subscriber);
        } finally {
            lock.unlock();
        }
    }

    public void unsubscribe(String topic, Subscriber subscriber) {
        lock.lock();
        try {
            // Get set of subscribers listening to the topic.
            Set<Subscriber> subscriberSet = subscribers.get(topic);

            // If no one listening, stop.
            if (subscriberSet == null) return;

            // Remove from set.
            subscriberSet.remove(subscriber);

            // Empty set? If so, remove the set.
            if (subscriberSet.isEmpty()) {
                subscribers.remove(topic);
            }
        } finally {
            lock.unlock();
        }
    }




}
